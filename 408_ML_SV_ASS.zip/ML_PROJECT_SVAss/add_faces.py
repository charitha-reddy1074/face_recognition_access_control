import cv2

def check_camera(index=0):
    cap = cv2.VideoCapture(index)
    if not cap.isOpened():
        print(f"Cannot open camera at index {index}")
        return False
    ret, frame = cap.read()
    if not ret:
        print(f"Failed to grab frame from camera at index {index}")
        return False
    cv2.imshow('frame', frame)
    cv2.waitKey(1000)
    cap.release()
    cv2.destroyAllWindows()
    return True

# Use the index found above in your main script
cap = cv2.VideoCapture(700)  # Replace 0 with the index found
