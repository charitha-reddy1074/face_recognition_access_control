import numpy as np
import os
import cv2
import csv
import tkinter as tk
from tkinter import *
from tkinter import messagebox, simpledialog
from PIL import Image, ImageTk
import face_recognition
from os import listdir
from os.path import isfile, join
from datetime import datetime
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

# Global variables to store the metrics
accuracy = precision = recall = f1 = 0

def check_camera(index=-1000):
    cap = cv2.VideoCapture(index)
    if not cap.isOpened():
        print(f"Cannot open camera at index {index}")
        return False
    ret, frame = cap.read()
    if not ret:
        print(f"Failed to grab frame from camera at index {index}")
        return False
    cap.release()
    return True

# Try different indices
camera_index = 700
for i in range(1000):
    if check_camera(i):
        camera_index = i
        break
else:
    print("No camera found")
    messagebox.showerror("Error", "No camera found")
    exit()

# Set up GUI
window = tk.Tk()  # Makes main window
window.wm_title("Face Recognition for Access Control")
window.config(background="#D8BFD8")  # Change background color to lilac

font = cv2.FONT_HERSHEY_SIMPLEX
small_font = cv2.FONT_HERSHEY_COMPLEX_SMALL
known_face_encodings = []
known_face_names = []

face_names = []
registration = False
capturing = False
current_mode = None  # 'register' or 'login'

# Corrected path handling
mypath = r"C:\Users\chari\OneDrive\Documents\ML_PROJECT_SVAss\FaceRecognitionAccessControl-main\people"  # Directory with images of known people

# Function to check if a file is an image
def is_image(file):
    image_extensions = ['.png', '.jpg', '.jpeg', '.bmp', '.gif']
    return any(file.lower().endswith(ext) for ext in image_extensions)

# Load known faces if the directory exists
def load_known_faces():
    global known_face_encodings, known_face_names
    if os.path.exists(mypath):
        for f in listdir(mypath):
            if isfile(join(mypath, f)) and is_image(f):
                try:
                    image = face_recognition.load_image_file(join(mypath, f))
                    face_encoding = face_recognition.face_encodings(image)[0]
                    known_face_encodings.append(face_encoding)
                    known_face_names.append(f[:-4])  # Assuming filenames are like 'john_doe.jpg'
                except Exception as e:
                    print(f"Error loading {f}: {e}")
    else:
        print(f"The directory {mypath} does not exist.")
        messagebox.showerror("Error", f"The directory {mypath} does not exist.")
        exit()

load_known_faces()

# Create log file if it doesn't exist
log_dir = "logs"
if not os.path.exists(log_dir):
    os.makedirs(log_dir)
file_name = os.path.join(log_dir, str(datetime.now().date()) + ".txt")
if not os.path.exists(file_name):
    with open(file_name, 'a+') as f:
        pass

# Graphics window
imageFrame = tk.Frame(window, width=600, height=600, bg="white")
imageFrame.grid(row=0, column=0, rowspan=3, padx=10, pady=2)

# Capture video frames
cap = cv2.VideoCapture(camera_index)
if not cap.isOpened():
    messagebox.showerror("Error", "Could not open video device")
    window.destroy()

def start_capture(mode):
    global capturing, current_mode
    capturing = True
    current_mode = mode
    register_button.grid_remove()
    login_button.grid_remove()
    back_button.grid(row=2, column=1, padx=5, pady=5)
    capture_button.grid(row=1, column=1, padx=5, pady=5)

def stop_capture():
    global capturing, current_mode
    capturing = False
    current_mode = None
    back_button.grid_remove()
    capture_button.grid_remove()
    register_button.grid(row=0, column=1, padx=5, pady=5)
    login_button.grid(row=1, column=1, padx=5, pady=5)
    welcome.config(text="")

def calculate_metrics(y_true, y_pred):
    global accuracy, precision, recall, f1
    tp = sum((y_true[i] == 1 and y_pred[i] == 1) for i in range(len(y_true)))
    tn = sum((y_true[i] == 0 and y_pred[i] == 0) for i in range(len(y_true)))
    fp = sum((y_true[i] == 0 and y_pred[i] == 1) for i in range(len(y_true)))
    fn = sum((y_true[i] == 1 and y_pred[i] == 0) for i in range(len(y_true)))

    accuracy = (tp + tn) / (tp + tn + fp + fn)
    precision = tp / (tp + fp) if (tp + fp) != 0 else 0
    recall = tp / (tp + fn) if (tp + fn) != 0 else 0
    f1 = 2 * precision * recall / (precision + recall) if (precision + recall) != 0 else 0

def display_metrics():
    metrics_window = Toplevel(window)
    metrics_window.wm_title("Metrics")
    metrics_window.config(background="#D8BFD8")

    Label(metrics_window, text=f"Accuracy: {accuracy:.2f}", font="Helvetica 16 bold", bg="#D8BFD8").pack(pady=10)
    Label(metrics_window, text=f"Precision: {precision:.2f}", font="Helvetica 16 bold", bg="#D8BFD8").pack(pady=10)
    Label(metrics_window, text=f"Recall: {recall:.2f}", font="Helvetica 16 bold", bg="#D8BFD8").pack(pady=10)
    Label(metrics_window, text=f"F1 Score: {f1:.2f}", font="Helvetica 16 bold", bg="#D8BFD8").pack(pady=10)

    fig, ax = plt.subplots(figsize=(6, 4), dpi=100)
    ax.bar(['Accuracy', 'Precision', 'Recall', 'F1 Score'], [accuracy, precision, recall, f1], color=['blue', 'green', 'red', 'purple'])
    ax.set_ylim([0, 1])
    ax.set_ylabel('Score')
    ax.set_title('Precision Metrics')

    # Embed the plot in the Tkinter window
    canvas = FigureCanvasTkAgg(fig, master=metrics_window)
    canvas.draw()
    canvas.get_tk_widget().pack(pady=10)

# Add button for displaying metrics after successful login
metrics_button = tk.Button(window, text="Show Metrics", font="Helvetica 16 bold", fg="white", bg="#8B008B", command=display_metrics)
metrics_button.grid(row=3, column=1, padx=5, pady=5)
metrics_button.grid_remove()

# In the capture_image function, add a condition to show the metrics button upon successful login
def capture_image():
    global current_mode
    ret, frame = cap.read()
    if not ret:
        messagebox.showerror("Error", "Failed to capture image")
        return
    frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    if current_mode == 'register':
        name = simpledialog.askstring("Input", "Enter your name:")
        if name:
            file_path = os.path.join(mypath, name + ".jpg")
            cv2.imwrite(file_path, cv2.cvtColor(frame, cv2.COLOR_RGB2BGR))
            messagebox.showinfo("Success", f"Image saved as {file_path}")
            load_known_faces()
            with open(file_name, 'a+') as f:
                f.write(str(datetime.now())[11:-10] + "\t" + name + "\n")
            welcome.config(text="Hi " + name.capitalize())
    elif current_mode == 'login':
        name = simpledialog.askstring("Input", "Enter your name:")
        if name:
            name_entry = name
            face_locations = face_recognition.face_locations(frame)
            face_encodings = face_recognition.face_encodings(frame, face_locations)
            y_true = []
            y_pred = []
            matches = []  # Define matches outside the loop
            for face_encoding in face_encodings:
                matches = face_recognition.compare_faces(known_face_encodings, face_encoding)
                face_distances = face_recognition.face_distance(known_face_encodings, face_encoding)
                best_match_index = np.argmin(face_distances)
                if matches[best_match_index]:
                    matched_name = known_face_names[best_match_index]
                    if matched_name == name_entry:
                        y_true.append(1)
                        y_pred.append(1)
                        messagebox.showinfo("Success", f"Access granted, welcome {name_entry}!")
                        welcome.config(text="Welcome, " + name_entry.capitalize())
                        with open(file_name, 'a+') as f:
                            f.write(str(datetime.now())[11:-10] + "\t" + name_entry + "\n")
                    else:
                        y_true.append(1)
                        y_pred.append(0)
                else:
                    y_true.append(1)
                    y_pred.append(0)
            if not any(matches):
                y_true.append(1)
                y_pred.append(0)
                messagebox.showerror("Error", "Access denied, face does not match.")
            calculate_metrics(y_true, y_pred)
            metrics_button.grid(row=3, column=1, padx=5, pady=5)  # Show metrics button
    stop_capture()
    

def load_known_faces():
    global known_face_encodings, known_face_names
    if os.path.exists(mypath):
        for f in listdir(mypath):
            if isfile(join(mypath, f)) and is_image(f):
                try:
                    image = face_recognition.load_image_file(join(mypath, f))
                    face_encodings = face_recognition.face_encodings(image)
                    if face_encodings:
                        face_encoding = face_encodings[0]
                        known_face_encodings.append(face_encoding)
                        known_face_names.append(f[:-4])  # Assuming filenames are like 'john_doe.jpg'
                except Exception as e:
                    print(f"Error loading {f}: {e}")
    else:
        print(f"The directory {mypath} does not exist.")
        messagebox.showerror("Error", f"The directory {mypath} does not exist.")
        exit()

def show_frame():
    global capturing
    ret, frame = cap.read()
    if not ret:
        return
    frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    cv2.putText(frame, str(datetime.now().strftime("%H:%M %d/%m/%Y")), (20, 20), font, .5, (255, 0, 0), 2, cv2.LINE_AA)
    if capturing:
        img = Image.fromarray(frame)
        imgtk = ImageTk.PhotoImage(image=img)
        display1.imgtk = imgtk
        display1.configure(image=imgtk)
    window.after(10, show_frame)

display1 = tk.Label(imageFrame)
display1.grid(row=1, column=0, columnspan=3, padx=10, pady=2)

welcome = tk.Label(window, text="", font="Helvetica 16 bold", fg="white", bg="#8B008B")
welcome.grid(row=3, column=1, padx=5, pady=5)

register_button = tk.Button(window, text="Register", font="Helvetica 16 bold", fg="white", bg="#8B008B", command=lambda: start_capture('register'))
register_button.grid(row=0, column=1, padx=5, pady=5)

login_button = tk.Button(window, text="Login", font="Helvetica 16 bold", fg="white", bg="#8B008B", command=lambda: start_capture('login'))
login_button.grid(row=1, column=1, padx=5, pady=5)

back_button = tk.Button(window, text="Back", font="Helvetica 16 bold", fg="white", bg="#8B008B", command=stop_capture)
back_button.grid(row=2, column=1, padx=5, pady=5)
back_button.grid_remove()

capture_button = tk.Button(window, text="Capture", font="Helvetica 16 bold", fg="white", bg="#8B008B", command=capture_image)
capture_button.grid(row=1, column=1, padx=5, pady=5)
capture_button.grid_remove()

log = ""
with open(file_name) as csv_file:
    csv_reader = csv.reader(csv_file, delimiter='\t')
    for row in csv_reader:
        log += row[0] + " " + row[1] + "\n"

show_frame()
window.mainloop()
