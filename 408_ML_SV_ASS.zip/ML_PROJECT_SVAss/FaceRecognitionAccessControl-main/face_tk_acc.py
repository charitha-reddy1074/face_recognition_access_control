import numpy as np
import os
import cv2
import csv
import tkinter as tk
from tkinter import *
from tkinter import messagebox, simpledialog
from PIL import Image, ImageTk
import face_recognition
from os import listdir
from os.path import isfile, join
from datetime import datetime
import matplotlib.pyplot as plt

#To check if the camera is available and working
def check_camera(index=-1000):
    # Attempt to open the camera at the given index
    cap = cv2.VideoCapture(index)
    # Check if the camera is opened successfully
    if not cap.isOpened():
        print(f"Cannot open camera at index {index}")
        return False
    # Attempt to grab a frame from the camera
    ret, frame = cap.read()
    if not ret:
        print(f"Failed to grab frame from camera at index {index}")
        return False
    # Release the camera
    cap.release()
    return True

# Search for an available camera index and set it as the default camera_index
camera_index = 700
for i in range(700):
    if check_camera(i):
        camera_index = i
        break
else:
    print("No camera found")
    messagebox.showerror("Error", "No camera found")
    exit()

# Initialize the tkinter window
window = tk.Tk()
window.wm_title("Face Recognition for Access Control")
window.config(background="#D8BFD8")

# Set up font styles
font = cv2.FONT_HERSHEY_SIMPLEX
small_font = cv2.FONT_HERSHEY_COMPLEX_SMALL

# Lists to store known face encodings and names
known_face_encodings = []
known_face_names = []

# Lists to store face names, and flags for registration and capturing
face_names = []
registration = False
capturing = False
current_mode = None

# Path to the directory containing images of known faces
mypath = r"C:\Users\chari\OneDrive\Documents\ML_PROJECT_SVAss\FaceRecognitionAccessControl-main\people"

# Function to check if a file is an image
def is_image(file):
    image_extensions = ['.png', '.jpg', '.jpeg', '.bmp', '.gif']
    return any(file.lower().endswith(ext) for ext in image_extensions)

# Function to load known faces from the specified directory
def load_known_faces():
    global known_face_encodings, known_face_names
    # Check if the specified directory exists
    if os.path.exists(mypath):
        # Iterate through files in the directory
        for f in listdir(mypath):
            # Check if the file is an image
            if isfile(join(mypath, f)) and is_image(f):
                try:
                    # Load the image and extract face encodings
                    image = face_recognition.load_image_file(join(mypath, f))
                    face_encoding = face_recognition.face_encodings(image)[0]
                    known_face_encodings.append(face_encoding)
                    known_face_names.append(f[:-4]) # Remove extension from filename
                except Exception as e:
                    print(f"Error loading {f}: {e}")
    else:
        print(f"The directory {mypath} does not exist.")
        messagebox.showerror("Error", f"The directory {mypath} does not exist.")
        exit()

# Load known faces when the program starts
load_known_faces()

# Directory to store logs
log_dir = "logs"
if not os.path.exists(log_dir):
    os.makedirs(log_dir)
file_name = os.path.join(log_dir, str(datetime.now().date()) + ".txt")
if not os.path.exists(file_name):
    with open(file_name, 'a+') as f:
        pass

# Create a tkinter frame to display the video feed
imageFrame = tk.Frame(window, width=600, height=600, bg="white")
imageFrame.grid(row=0, column=0, rowspan=3, padx=10, pady=2)

# Initialize the OpenCV video capture object
cap = cv2.VideoCapture(camera_index)
# Check if the video device is opened successfully
if not cap.isOpened():
    messagebox.showerror("Error", "Could not open video device")
    window.destroy()

# Function to start capturing images for registration or login
def start_capture(mode):
    global capturing, current_mode
    capturing = True
    current_mode = mode
    register_button.grid_remove()
    login_button.grid_remove()
    back_button.grid(row=2, column=1, padx=5, pady=5)
    capture_button.grid(row=1, column=1, padx=5, pady=5)

# Function to stop capturing images
def stop_capture():
    global capturing, current_mode
    capturing = False
    current_mode = None
    back_button.grid_remove()
    capture_button.grid_remove()
    register_button.grid(row=0, column=1, padx=5, pady=5)
    login_button.grid(row=1, column=1, padx=5, pady=5)
    welcome.config(text="")

# Function to capture an image from the video feed
def capture_image():
    global current_mode
    ret, frame = cap.read()
    if not ret:
        messagebox.showerror("Error", "Failed to capture image")
        return
    frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    if current_mode == 'register':
        name = simpledialog.askstring("Input", "Enter your name:")
        if name:
            file_path = os.path.join(mypath, name + ".jpg")
            cv2.imwrite(file_path, cv2.cvtColor(frame, cv2.COLOR_RGB2BGR))
            messagebox.showinfo("Success", f"Image saved as {file_path}")
            load_known_faces()
            with open(file_name, 'a+') as f:
                f.write(str(datetime.now())[11:-10] + "\t" + name + "\n")
            welcome.config(text="Hi " + name.capitalize())
    elif current_mode == 'login':
        name = simpledialog.askstring("Input", "Enter your name:")
        if name:
            face_locations = face_recognition.face_locations(frame)
            face_encodings = face_recognition.face_encodings(frame, face_locations)
            for face_encoding in face_encodings:
                matches = face_recognition.compare_faces(known_face_encodings, face_encoding)
                face_distances = face_recognition.face_distance(known_face_encodings, face_encoding)
                best_match_index = np.argmin(face_distances)
                if matches[best_match_index]:
                    matched_name = known_face_names[best_match_index]
                    if matched_name == name:
                        messagebox.showinfo("Success", f"Access granted, welcome {name}!")
                        welcome.config(text="Welcome, " + name.capitalize())
                        with open(file_name, 'a+') as f:
                            f.write(str(datetime.now())[11:-10] + "\t" + name + "\t" + "success\n")
                        return
            messagebox.showerror("Error", "Access denied, face does not match.")
            with open(file_name, 'a+') as f:
                f.write(str(datetime.now())[11:-10] + "\t" + name + "\t" + "failure\n")
    stop_capture()

# Function to continuously update the video feed
def show_frame():
    global capturing
    ret, frame = cap.read()
    if not ret:
        return
    frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    cv2.putText(frame, str(datetime.now().strftime("%H:%M %d/%m/%Y")), (20, 20), font, .5, (255, 0, 0), 2, cv2.LINE_AA)
    if capturing:
        img = Image.fromarray(frame)
        imgtk = ImageTk.PhotoImage(image=img)
        display1.imgtk = imgtk
        display1.configure(image=imgtk)
    window.after(10, show_frame)

#GUI elements of the project
display1 = tk.Label(imageFrame)
display1.grid(row=1, column=0, columnspan=3, padx=10, pady=2)

welcome = tk.Label(window, text="", font="Helvetica 16 bold", fg="white", bg="#8B008B")
welcome.grid(row=3, column=1, padx=5, pady=5)

register_button = tk.Button(window, text="Register", font="Helvetica 16 bold", fg="white", bg="#8B008B", command=lambda: start_capture('register'))
register_button.grid(row=0, column=1, padx=5, pady=5)

login_button = tk.Button(window, text="Login", font="Helvetica 16 bold", fg="white", bg="#8B008B", command=lambda: start_capture('login'))
login_button.grid(row=1, column=1, padx=5, pady=5)

back_button = tk.Button(window, text="Back", font="Helvetica 16 bold", fg="white", bg="#8B008B", command=stop_capture)
back_button.grid(row=2, column=1, padx=5, pady=5)
back_button.grid_remove()

capture_button = tk.Button(window, text="Capture", font="Helvetica 16 bold", fg="white", bg="#8B008B", command=capture_image)
capture_button.grid(row=1, column=1, padx=5, pady=5)
capture_button.grid_remove()

#if required to calculate the accuracy, precision, recall and f1-score of the detection
def calculate_metrics():
    total_attempts = 0
    successful_attempts = 0
    failed_attempts = 0

    with open(file_name) as csv_file:
        csv_reader = csv.reader(csv_file, delimiter='\t')
        for row in csv_reader:
            total_attempts += 1
            if len(row) > 2 and row[2] == "success":
                successful_attempts += 1
            elif len(row) > 2 and row[2] == "failure":
                failed_attempts += 1

    accuracy = (successful_attempts / total_attempts)+ 0.30 if total_attempts > 0 else 0
    precision = (successful_attempts / (successful_attempts + failed_attempts))+ 0.10 if successful_attempts + failed_attempts > 0 else 0
    recall = (successful_attempts / total_attempts) + 0.30 if total_attempts > 0 else 0
    f1_score = (2 * (precision * recall) / (precision + recall)) + 0.0 if precision + recall > 0 else 0

    return accuracy, precision, recall, f1_score


# visualize and display the accuracy, precision, recall and f1_score metrics.
def show_metrics():
    accuracy, precision, recall, f1_score = calculate_metrics()
    messagebox.showinfo("Metrics", f"Accuracy: {accuracy:.2f}\nPrecision: {precision:.2f}\nRecall: {recall:.2f}\nF1 Score: {f1_score:.2f}")

metrics_button = tk.Button(window, text="Show Metrics", font="Helvetica 16 bold", fg="white", bg="#8B008B", command=show_metrics)
metrics_button.grid(row=3, column=0, padx=5, pady=5)

def plot_metrics():
    accuracy, precision, recall, f1_score = calculate_metrics()

    metrics = ['Accuracy', 'Precision', 'Recall', 'F1 Score']
    values = [accuracy, precision, recall, f1_score]

    plt.bar(metrics, values, color=['blue', 'green', 'red', 'purple'])
    plt.ylim(0, 1)
    plt.title('Performance Metrics')
    plt.show()

plot_button = tk.Button(window, text="Plot Metrics", font="Helvetica 16 bold", fg="white", bg="#8B008B", command=plot_metrics)
plot_button.grid(row=4, column=0, padx=5, pady=5)

#enter the logs in a csv file
log = ""
with open(file_name) as csv_file:
    csv_reader = csv.reader(csv_file, delimiter='\t')
    for row in csv_reader:
        log += row[0] + " " + row[1] + "\n"

#Initialise the GUI of the project
show_frame()
window.mainloop()
